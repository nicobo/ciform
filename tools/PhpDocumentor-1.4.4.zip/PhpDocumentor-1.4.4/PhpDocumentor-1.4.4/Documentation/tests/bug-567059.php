<?php
/**
* @package tests
*/
/**
* tests linking to methods and vars
*/
class a{
var $a;
function a(){}
}

/**
* test links to methods and vars
*
* @param integer testing
* @ param integer testing
* @see a::$a
* @see a::a()
*/
function aa_567059(&$test,$two){}
?>
