<?php
/**
* @package tests
*/

/**
* Short Desc Test. This is the Extended Comment
* and so is this
*
*/
define("testContantBlah","hi");

/**
* Short Desc 2.0 Test. This is the Extended Comment
* and so is this
*
*/
define("testContantBlah2","hi");

/**
* Short Desc 2.0 Test.	This is the Extended Comment
* and so is this
*/
define("testContantBlah3","hi");

/**
* Short Desc 2.0 Test This is still the short desc Comment
* and this is the extended
*/
define("testContantBlah4","hi");

/**
* Short Desc 2.0 Test This is still the short desc Comment
* and so is this
*
* Now were to the extended
*/
define("testContantBlah5","hi");
