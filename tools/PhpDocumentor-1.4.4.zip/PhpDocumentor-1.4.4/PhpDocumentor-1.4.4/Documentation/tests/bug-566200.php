<?php
/**
* @package tests
*/
/**
* tests function param bug
*/
function ezStartPageNumbers($x,$y,$size,$pos='left',$pattern='{PAGENUM} of {TOTALPAGENUM}',$num=''){}
?>