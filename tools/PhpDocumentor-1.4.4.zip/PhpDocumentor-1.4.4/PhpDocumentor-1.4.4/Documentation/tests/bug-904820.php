<?php

/**
* This is a test of a package with a . in its name
*
* @package	org.phpdoc
*/

/**
* I'm an element
*/
define('element',true);
?>
