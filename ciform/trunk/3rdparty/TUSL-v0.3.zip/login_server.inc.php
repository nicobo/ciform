<?php

error_reporting(0);

if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME']))
{
    exit(0);
}

require ('settings.inc.php');

if(@$_GET[$variable_action] == 'icon')
{
	header('Content-Type: image/x-icon');
	echo base64_decode($icon);
	exit();
}

$http_host  = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost');

require ('Pear_Crypt_HMAC.php');

$show_login_form = false;

ini_set('session.referer_check', $_SERVER['SCRIPT_NAME']);
ini_set('session.use_trans_sid', 0);
ini_set('url_rewriter.tags', '');

//    set session to use cookie only, for security reasons
ini_set('session.use_cookies', 1);
ini_set('session.use_only_cookies', 1);
session_set_cookie_params(0);

//    set caching
session_cache_limiter('nocache');
session_cache_expire(0);

//    set session name
session_name($session_name);

//    starting session
session_start();

if(@$_GET[$variable_action] == 'logout')
{
	session_unset();
	$_SESSION = array();
	session_destroy();

	header('Location: http://' . $http_host . $_SERVER['SCRIPT_NAME'] . "?");
	echo "Redirecting...";
	exit();
}

$user = isset($_SESSION['user']) ? $_SESSION['user'] : false;
$pass = isset($_SESSION['pass']) ? $_SESSION['pass'] : false;
$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : false;
$agent = isset($_SESSION['agent']) ? $_SESSION['agent'] : false;
$ip = isset($_SESSION['ip']) ? $_SESSION['ip'] : false;
$time = isset($_SESSION['time']) ? $_SESSION['time'] : false;
$key = isset($_SESSION['key']) ? $_SESSION['key'] : false;

if(!$uid)
{
	//    if NOT $uid we check the $_POST
	$_POST[$variable_user] = isset($_POST[$variable_user]) ? strip_tags($_POST[$variable_user]) : false;
	$_POST[$variable_pass] = isset($_POST[$variable_pass]) ? strip_tags($_POST[$variable_pass]) : false;
	$_POST[$variable_key] = isset($_POST[$variable_key]) ? strip_tags($_POST[$variable_key]) : false;

	if($_POST[$variable_user] && $_POST[$variable_pass] && $_POST[$variable_key])
	{
		if($_POST[$variable_key] == $key)
		{
			$secret_key = $_POST[$variable_key];
			$hmac = new Crypt_HMAC(sha1($secret_key), 'sha1');
		}
		else
		{
			$secret_key = 'This key is supposed to invalidate authentication';
			$hmac = new Crypt_HMAC($secret_key, 'sha1');
		}
		
		if(($hmac->hash(@$secret["{$_POST[$variable_user]}"]) === $_POST[$variable_pass]))
		{
			session_unset();
			$_SESSION = array();
			session_destroy();
			
			ini_set('session.referer_check', $_SERVER['SCRIPT_NAME']);
			ini_set('session.use_trans_sid', 0);
			ini_set('url_rewriter.tags', '');
			ini_set('session.use_cookies', 1);
			ini_set('session.use_only_cookies', 1);
			session_set_cookie_params(0);
			session_cache_limiter('nocache');
			session_cache_expire(0);
			session_name($session_name);
			session_id($script_name . sha1(microtime()) . $script_name);
			session_start();
			
			//    set session login variables
			$_SESSION['user'] = $_POST[$variable_user];
			$_SESSION['pass'] = $_POST[$variable_pass];
			$_SESSION['agent'] = $_SERVER['HTTP_USER_AGENT'];
			$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
			$_SESSION['time'] = time();
			$_SESSION['uid'] = sha1($http_host . $_SESSION['user'] . $_SESSION['pass'] . $_SESSION['agent'] . $_SESSION['ip']);
		}
		else
		{
			$show_login_form = true;
		}
	}
	else
	{
		$show_login_form = true;
	}
}
else
{
	if(($uid != sha1($http_host . $user . $pass . $_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR'])))
	{
		$show_login_form = true;
	}
	
	//    set session timeout
	if((time() - $time) > $session_timeout)
	{
		$show_login_form = true;
	}
	
	if($time > time())
	{
		$show_login_form = true;
	}
}

if($show_login_form)
{
	session_unset();
	$_SESSION = array();
	session_destroy();
	
	ini_set('session.referer_check', $_SERVER['SCRIPT_NAME']);
	ini_set('session.use_trans_sid', 0);
	ini_set('url_rewriter.tags', '');
	ini_set('session.use_cookies', 1);
	ini_set('session.use_only_cookies', 1);
	session_set_cookie_params(0);
	session_cache_limiter('nocache');
	session_cache_expire(0);
	session_name($session_name);
	session_id(sha1(microtime()));
	session_start();
	
	//   set key
	$secret_key = sha1(microtime());
	$_SESSION['key'] = $secret_key ;
	
	require  "login_client.inc.php";

	exit();
}

error_reporting(E_ALL & ~(E_NOTICE));

header('Cache-Control: public');
header('Cache-Control: public');
header('Cache-Control: public');
header('Cache-Control: public');
header('Cache-Control: public');
header('Expires: Sun, 19 Apr 2099 05:55:00 GMT');
header('Pragma: public');
?>