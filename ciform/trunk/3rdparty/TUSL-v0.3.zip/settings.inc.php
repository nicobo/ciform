<?php
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME']))
{
    exit(0);
}

$script_name = "TUSL";
###############################  SETTINGS  ###############################

//  1. use sha1 twice to encrypt your usernames and passwords and add results to this array
$secret = array(
				'c4033bff94b567a190e33faa551f411caef444f2' => 'c4033bff94b567a190e33faa551f411caef444f2',
				
				);

//  2.  session timeout. default: 5 hours
$session_timeout = 60 * 60 * 5;

//  3.
$session_name = $script_name;

//  4.
$variable_action = "action";

//  5.
$variable_user = $script_name . "_user";

//  6.
$variable_pass = $script_name . "_pass";

//  7.
$variable_key = $script_name . "_key";

//  8.
$link = '<link rel="SHORTCUT ICON" href="' . $_SERVER['SCRIPT_NAME'] . "?$variable_action=icon" . '" type="image/x-icon" />';

//  9.
$meta = '<meta http-equiv="content-type" content="text/html; charset=utf-8" />';

//  10.
$script = "";

//  11.
$title = "<title>$script_name :: Login</title>";

//  12.
$style = <<<EOF
<style type="text/css">
<!--
	body.$script_name
	{
		color:rgb(0,66,174);
	}

	form.$script_name, input.$script_name
	{
		font-family:		"Trebuchet MS",Verdana, Helvetica, Arial;
		font-size:			14px;
		color:				rgb(0,66,174);
	}

	div.$script_name
	{
		border:			1px solid rgb(120,172,255);
		background:		White;
		z-index:		2;
		margin-top:     20%;
		margin-right:   20%;
		margin-left:    20%;
		font-family:		"Trebuchet MS",Verdana, Helvetica, Arial;
		font-size:			14px;
		color:				rgb(0,66,174);
		padding:        10px;
	}
-->
</style>
EOF;

//  13.  use base64_encode to encode contents of your icon
$icon = "AAABAAEAEBAAAAEACABoBQAAFgAAACgAAAAQAAAAIAAAAAEACAAAAAAAQAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAA////AP/f/wD9/v8A5PH6AN3t+QCy2fIAsdfxALLX8QC02fEAernnAGqy5AAYtOUAUsLqAGuz5AB1t+MAY67jAGav4wBbquEAXKrhAF6r4QBLo94AFK3iABux5ABDuucARZ7dABig2QAOsOMAIbPkAGTF6gCFttgAD6HaABWi2gAuo94Axef3AMrs+ADf8foA4/P7AH+vzgANfLoAGH65AB19uAAHergAAnm6ACF8twAFe7oAAna4AByh2gAEm9kAJJ3XACux5ABVueYAW7TlACN8twAje7YAGnSxABp0sAATerYAOJ/YACSW2gAFm9kAOajdAEGj3gAknd0ALJ7dAA2h2QBGpeAAJK3iAIzJ6QCLyesAodLvAJHI6wC32vAAzur4AAt9uwARgMsAD22uABZysQAAbq8AAGyuABmK1QAXd7MAEn+7AB54tQAYdrMAGXWzACKO1wAjis8AAY7QACyU2QBIotoAL5LTADWY2gA2mtsAOprbAAig2gA2n90AO57cADub3AA+m9wAP53cAEWg3gBGod4ASKLeAEqi3gBGpd8ASaXfAFOn4ABMpd8AVKfgAFap4ABOpN8AT6XfAFeo4QBRpt8AWanhAEGu4gBjr+MAE7DjAAqs4gBer+IATLXkAByw4wBis+QAZ7HjAGex5ABnsuQAa7TlAHS45gBstOUAXqziAHa55gBvtuUAd7rnAHm75wCAvegAgL/oAHq85wBosuQAg7/pAIzF6gCGwekAjcXqADWW1QAKfLoAjsbrAIfB6QCRxusAMZbZAJPI7ACWyewAlMjrAJ3N7gCezu4AqtTwALDX8QCu1fAAo9DuAHC25QC/3/IAuN3zAMPg9ADB3/MA1On3AOv1+wCKutoAYa3iAFqq4QCFv+UA1Oj2APj8/gD5/P4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEBAQEBAQEBAQEBAAEeTE03OFRROSeQKitOJgEBS6kBAahaOjEvIEE8WE8BAVABDkcBASR5Q3p2dzAuAQFWAZ1nkaABIjIcDBtfLQEBWYABCWxpAUkdDRcWH0oBAVwViwGbakWqAQEjGBpSAQFka26NAZo+NHQzASU9KAEBZacTcZcBeGBAPyEBRCkBAXB1pnMKAW9dQns7Rp8sAQFrgYoUhwGnXpmqYQZINQEBgomeEBEEohljcn4DDzYBAX+OiIR8k6sFlpwBB49TAQGFmIyGnguSoaSjlWVbVQEBCIN9Em1waBVmZGKUV6UBAAEBAQEBAQEBAQEBAQEBAIABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIABAAA=";
?>