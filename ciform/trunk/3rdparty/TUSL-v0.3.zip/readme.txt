Using TUSL:

upload TUSL files to server root (eg. /home/public_html/)
insert following line on top of your main script (usually index.php):

require ($_SERVER['DOCUMENT_ROOT'] . "/login_server.inc.php");