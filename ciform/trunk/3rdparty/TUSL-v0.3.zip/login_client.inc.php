<?php
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME']))
{
    exit(0);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?= isset($link) ? $link . "\n" : '';?>
<?= isset($meta) ? $meta . "\n" : '';?>
<?= isset($script) ? $script . "\n" : '';?>
<?= isset($title) ? $title . "\n" : '';?>
<?= isset($style) ? $style . "\n" : '';?>
</head>
<body>
<script language="javascript" type="text/javascript">
<?php require "sha1.js";?>
function submit_form()
{
	document.forms["login"].<?= $variable_user;?>.value = hex_sha1(hex_sha1(document.forms["login"].username.value));
	document.forms["login"].username.value = '';
	document.forms["login"].<?= $variable_pass;?>.value = hex_hmac_sha1(hex_sha1(document.forms["login"].<?= $variable_key;?>.value), hex_sha1(hex_sha1(document.forms["login"].password.value)));
	document.forms["login"].password.value = '';
	document.forms["login"].submit();
	return true;
}
</script>
<noscript>
<center>
	<div class="<?= $script_name;?>">
		Please enable JavaScript. Don't push Submit button while JavaScript is disabled.
	</div>
</center>
</noscript>
<form name="login" action="<?= $_SERVER['SCRIPT_NAME'] . ((!empty($_SERVER["QUERY_STRING"])) ? '?' . $_SERVER["QUERY_STRING"] : '');?>" onsubmit="return submit_form()" method="post" class="<?= $script_name;?>">
	<center>
		<div class="<?= $script_name;?>">
			Username: <input type="text" name="username" class="<?= $script_name;?>" />
			<input type="hidden" name="<?= $variable_user;?>" />
			<br /><br />
			Password: <input type="password" name="password" class="<?= $script_name;?>" />
			<input type="hidden" name="<?= $variable_pass;?>" />
			<br /><br />
			<input type="hidden" name="<?= $variable_key;?>" value="<?= $secret_key;?>" />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" name="log in" value="Login" class="<?= $script_name;?>" />
			<img src="<?= $_SERVER['SCRIPT_NAME'] . '?action=icon';?>" alt="<?= $script_name;?>" title="<?= $script_name;?>" />
<?php
if($uid && !empty($_POST))
{
	foreach($_POST as $key => $value)
	{
		echo "\t\t\t<input type=\"hidden\" name=\"$key\" value=\"$value\" />\r\n";
	}
}
?>
		</div>
	</center>
</form>
</body>
</html>