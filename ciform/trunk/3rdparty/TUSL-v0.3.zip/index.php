<?php
require ("." . "/login_server.inc.php");

echo "You are successfully logged in! <a href='?action=logout'>logout</a>";
?>